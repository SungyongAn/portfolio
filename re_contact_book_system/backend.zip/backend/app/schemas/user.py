from app.models.class_model import AssignmentTypeEnum, PermissionLevelEnum
from app.models.user import RoleEnum
from pydantic import BaseModel, EmailStr, Field
from datetime import datetime


# ログインリクエスト
class LoginRequest(BaseModel):
    email: EmailStr = Field(..., description="メールアドレス")
    password: str = Field(..., min_length=6, description="パスワード")


# ログインレスポンス
class LoginResponse(BaseModel):
    access_token: str = Field(..., description="アクセストークン（短命）")
    token_type: str = Field(default="bearer", description="トークンタイプ")
    expires_in: int = Field(..., description="有効期限（秒）")
    role: str = Field(..., description="ユーザーロール")
    name: str = Field(..., description="ユーザー名")
    user_id: int = Field(..., description="ユーザーID")


# トークンリフレッシュレスポンス
class TokenRefreshResponse(BaseModel):
    access_token: str = Field(..., description="新しいアクセストークン")
    token_type: str = Field(default="bearer", description="トークンタイプ")
    expires_in: int = Field(..., description="有効期限（秒）")


# ユーザー作成リクエスト
class UserCreate(BaseModel):
    email: EmailStr = Field(..., description="メールアドレス")
    password: str = Field(..., min_length=6, description="パスワード")
    name: str = Field(..., min_length=1, max_length=100, description="氏名")
    role: str = Field(..., description="ユーザーロール (student/teacher/admin)")

    class Config:
        json_schema_extra = {
            "example": {
                "email": "student@school.ac.jp",
                "password": "password123",
                "name": "山田 太郎",
                "role": "student"
            }
        }


# ユーザー更新リクエスト
class UserUpdate(BaseModel):
    name: str | None = Field(None, min_length=1, max_length=100, description="氏名")
    password: str | None = Field(None, min_length=6, description="新しいパスワード")


# ユーザー情報レスポンス
class UserResponse(BaseModel):
    id: int
    email: str
    name: str
    role: str
    created_at: datetime

    class Config:
        from_attributes = True


# クラス情報付きユーザーレスポンス
class UserWithClassResponse(BaseModel):
    id: int
    email: str
    name: str
    role: str
    class_name: str | None = None
    grade_number: int | None = None
    created_at: datetime

    class Config:
        from_attributes = True


# 管理者権限でのユーザー検索時の教師情報
class TeacherAssignmentSummary(BaseModel):
    assignment_type: AssignmentTypeEnum

    is_primary: bool
    permission_level: PermissionLevelEnum

    class Config:
        from_attributes = True


# 管理者権限でのユーザー検索
class AdminUserListResponse(BaseModel):
    id: int
    name: str
    email: str
    role: str
    grade_number: int | None
    class_name: str | None


